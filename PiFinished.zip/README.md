Main Class
	Declare Variables -
		Maybe needed to compare outcome to the answer we want?...     !
		Pi Start which will be called strtp                           @
		infinite loop variable for n int + 2(odds)                    #
		String for length limited in this case ""                     $
		Another string but name for the same as the last one          %
		Here will be the loop                                         ^
			If n+2 of strp/ by n+2                                @
				(might end up using % because of odds though)    #
			same case as on top but declare a - everyother on is + then -    @#
			make the strtp +      @
			here is n+2       #
			use 2nd string name to = to limt       $%
			Declare the output or comparison as the first ? varible     !

		system output here is the answer __