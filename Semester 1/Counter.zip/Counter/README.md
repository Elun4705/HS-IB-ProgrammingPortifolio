Starter for 3.1 Encapsulation in code and Unit Testing.
  by Emmanuel Luna
