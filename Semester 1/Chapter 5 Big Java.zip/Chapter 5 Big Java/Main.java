/**
* This class just displays the actual result of the Bank Account
* @author  Emmanuel Luna
* @version 1.0
* @since   2020-11-04
*/

import java.util.Scanner;

class Main {
  public static void main(String[] args) {

    Scanner s1 = new Scanner(System.in);
    int mItem;
    double mTotal, mTip, mFinal;

    System.out.println("Thank you you for dinning with us! We would really appreaciate if you leaved a tip!");
    System.out.println("We give a small survey about your satisfaction to give you the best option!");
    System.out.println("Enter 1 for Totally satisfied");
    System.out.println("Enter 2 for Satisfied");
    System.out.println("Enter 3 for Not satisfied");
    mItem = s1.nextInt();

    System.out.println("Also what was your total?");
    mTotal = s1.nextDouble();

    switch (mItem) {
      /**
      * @Herethe swithc is being used to check the user's input on whether
      * they were satisfied or not on a scale from 3 to 1
      * There are 3 cases here for their satisfaction
      */
      
      case 1:
        System.out.println("We are glad you were totally satisfied! Your recommended tip is 20% of your total.");

        mTip = mTotal * 0.2;
        mFinal = mTip + mTotal;

        System.out.println("In this case $" + mTip);
        System.out.println("Making your total without tax $" + mFinal);
      break;
      
      case 2:
        System.out.println("We are glad you were satisfied! We will do our best to improve Your recommended tip is 15% of your total.");

        mTip = mTotal * 0.15;
        mFinal = mTip + mTotal;

        System.out.println("In this case $" + mTip);
        System.out.println("Making your total without tax $" + mFinal);
      break;
      
      case 3:
        System.out.println("We are are sorry you weren't satisfied... We promise to do better the next time you come. Your recommended tip is 10% of your total.");

        mTip = mTotal * 0.1;
        mFinal = mTip + mTotal;

        System.out.println("In this case $" + mTip);
        System.out.println("Making your total without tax $" + mFinal);
      break;

      default:

      break;
    }

  }
}